const userLength = 'Tesla';
